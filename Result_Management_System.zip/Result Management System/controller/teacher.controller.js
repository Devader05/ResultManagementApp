var db = require('../models')
const Student = db.students;
const teacher_option_get = (req,res) => {
    res.render("teacher/option")
};
const teacher_add_get = (req, res) => {
    res.render("teacher/addstudent");
};
const teacher_add_post = async (req, res) => {
    const singleStudent = Student.create({
        name : req.body.name,  
        roll : req.body.roll,             
        dob : req.body.dob,
        score : req.body.score        
    })
    try {
        await singleStudent.save();
        // res.redirect("/teacher/add");
      } catch {
        // res.send("error")
        res.redirect("/teacher/add");
    }
};
const teacher_viewall_get = async (req, res) => {
    const allStudents = await Student.findAll() 
    res.render("teacher/viewall", {student : allStudents})
};

const teacher_edit_get =async (req, res) => {
    const user = await Student.findByPk(req.params.id)
    res.render("teacher/edit",{user : user})
};
const teacher_edit_post =async (req, res) => {
    const id = req.params.id;
    const user =await Student.update(req.body, {
        where: { id: id }
      });
    res.redirect("/teacher/viewall")
};
const teacher_delete_get =async (req, res) => {
    const id = req.params.id;
    await Student.destroy({
        where: { id: id }
      })
        
    res.redirect("/teacher/viewall")
};
module.exports = {
    teacher_option_get,
    teacher_add_get,
    teacher_add_post,
    teacher_viewall_get,
    teacher_edit_get,
    teacher_edit_post,
    teacher_delete_get
}