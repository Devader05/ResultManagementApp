module.exports = (sequelize, DataTypes) => {
    const Student = sequelize.define("student", {
        name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        roll:
        {
            type: DataTypes.INTEGER

        },
        dob:
        {
            type: DataTypes.DATEONLY
        },
        score:
        {
            type: DataTypes.INTEGER
        }
    }, 
    {

        sequelize,
        modelName: 'Student',
        timestamps: false
    });


    return Student;
};
